<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; BizVelocity Cloud ERP &#8212; WordPress</title>
	<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript' src='http://www.bizvelocity.biz/wordpress/wp-includes/js/swfobject.js?ver=2.2-20120417'></script>
<script type='text/javascript' src='http://www.bizvelocity.biz/wordpress/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://www.bizvelocity.biz/wordpress/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://www.bizvelocity.biz/wordpress/wp-content/uploads/wpcu3er/jquery.cu3er.js?ver=5.1'></script>
<link rel='stylesheet' id='dashicons-css'  href='http://www.bizvelocity.biz/wordpress/wp-includes/css/dashicons.min.css?ver=5.1' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-css'  href='http://www.bizvelocity.biz/wordpress/wp-includes/css/buttons.min.css?ver=5.1' type='text/css' media='all' />
<link rel='stylesheet' id='forms-css'  href='http://www.bizvelocity.biz/wordpress/wp-admin/css/forms.min.css?ver=5.1' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-css'  href='http://www.bizvelocity.biz/wordpress/wp-admin/css/l10n.min.css?ver=5.1' type='text/css' media='all' />
<link rel='stylesheet' id='login-css'  href='http://www.bizvelocity.biz/wordpress/wp-admin/css/login.min.css?ver=5.1' type='text/css' media='all' />
<style type="text/css">
            .login h1 a { background-image:url(http://www.bizvelocity.biz/wordpress/wp-content/uploads/BizVelocity-logo-5.png) !important;background-size:inherit !important; }
        </style>		<style type="text/css">
		#wp_native_dashboard_language {padding: 2px;border-width: 1px;border-style: solid;height: 2em;vertical-align:top;margin-top: 2px;font-size:16px;width:100%; }
		#wp_native_dashboard_language option { padding-left: 4px; }
		</style>
			<meta name='robots' content='noindex,noarchive' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width" />
	<link rel="icon" href="http://www.bizvelocity.biz/wordpress/wp-content/uploads/cropped-clover.icon-1-32x32.png" sizes="32x32" />
<link rel="icon" href="http://www.bizvelocity.biz/wordpress/wp-content/uploads/cropped-clover.icon-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="http://www.bizvelocity.biz/wordpress/wp-content/uploads/cropped-clover.icon-1-180x180.png" />
<meta name="msapplication-TileImage" content="http://www.bizvelocity.biz/wordpress/wp-content/uploads/cropped-clover.icon-1-270x270.png" />
	</head>
	<body class="login login-action-login wp-core-ui  locale-en-us">
		<div id="login">
		<h1><a href="http://www.bizvelocity.biz/wordpress/home-en" title="BizVelocity Cloud ERP">BizVelocity Cloud ERP</a></h1>
	
	<form name="loginform" id="loginform" action="http://www.bizvelocity.biz/wordpress/wp-login.php" method="post">
	<p>
		<label for="user_login">Username or Email Address<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
				<label>Language</label><br/>
		<select id="wp_native_dashboard_language" name="wp_native_dashboard_language" tabindex="30">
		<option value="en_US" selected="selected"><b>English</b>&nbsp;<i>(en_US)</i></option><option value="zh_CN"><b>中文</b>&nbsp;<i>(zh_CN)</i></option>		</select>
		<br/><br/>
			<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
				<input type="hidden" name="redirect_to" value="http://www.bizvelocity.biz/wordpress" />
					<input type="hidden" name="testcookie" value="1" />
	</p>
	</form>

			<p id="nav">
					<a href="http://www.bizvelocity.biz/wordpress/wp-login.php?action=lostpassword">Lost your password?</a>
				</p>
	
	<script type="text/javascript">
	function wp_attempt_focus(){
	setTimeout( function(){ try{
			d = document.getElementById('user_login');
				d.focus();
	d.select();
	} catch(e){}
	}, 200);
	}

			wp_attempt_focus();
			if(typeof wpOnload=='function')wpOnload();
			</script>

			<p id="backtoblog"><a href="http://www.bizvelocity.biz/wordpress/home-en/">
		&larr; Back to BizVelocity Cloud ERP	</a></p>
			
	</div>

	
	<script type="text/javascript">(function() {
				var expirationDate = new Date();
				expirationDate.setTime( expirationDate.getTime() + 31536000 * 1000 );
				document.cookie = "pll_language=en; expires=" + expirationDate.toUTCString() + "; path=/wordpress/";
			}());</script>	<div class="clear"></div>
	</body>
	</html>
	
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.w3-edge.com/products/


Served from: www.bizvelocity.biz @ 2020-01-29 23:52:57 by W3 Total Cache
-->